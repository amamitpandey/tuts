var express = require("express");
var jwt = require('jsonwebtoken');

var userService = require('../services/userService');

var config = require('../config');

var secretKey = config.secretKey;

module.exports = (app, express) => {

  var user = express.Router();

  user.post('/userregister', (req, res) => {
    var registrationData = req.body;
    userService.userregister(registrationData, (response) => {
      res.send(response);
    });
  });

  user.post('/resendemailOTP', (req, res) => {
    var resendOTPData = req.body;
    userService.resendemailOTP(resendOTPData, (response) => {
      res.send(response);
    });
  });

  user.post('/verifyemail', (req, res) => {
    var verifyemailData = req.body;
    userService.verifyemail(verifyemailData, (response) => {
      res.send(response);
    });
  });

  user.post('/login', (req, res) => {
    var loginData = req.body;
    userService.login(loginData, (response) => {
      res.send(response);
    });
  });

  // FB Login
  user.post('/fblogin', (req, res) => {
    var loginData = req.body;
    userService.fblogin(loginData, (response) => {
      res.send(response);
    });
  });

  user.post('/forgotpassword', (req, res) => {
    var forgotpasswordData = req.body;
    userService.forgotpassword(forgotpasswordData, (response) => {
      res.send(response);
    });
  });

  user.get('/getcategorydata', (req, res) => {
    userService.getcategorydata((response) => {
      res.send(response);
    });
  });

  //=================
  //Middleware to check token
  //=================

  user.use((req, res, next) => {
    var token = req.body.token || req.param('token') || req.headers['x-access-token'];
    //console.log(token);
    if (token) {
      jwt.verify(token, secretKey, (err, decoded) => {
        if (err) {
          res.status(403).send({
            success: false,
            message: "Authentication failed"
          });
        } else {
          req.decoded = decoded;
          next();
        }
      });
    } else {
      res.status(403).send({
        success: false,
        message: "Authentication token required"
      });
    }
  });

  //=================
  //  Middleware end
  //=================


  user.get('/getprofileData', (req, res) => {
    var tokendata = req.decoded;
    userService.getprofileData(tokendata, (response) => {
      res.send(response);
    });
  });

  user.post('/updateProfile', (req, res) => {
    var updateprofileData = req.body;
    var tokendata = req.decoded;
    userService.updateProfile(updateprofileData, tokendata, (response) => {
      res.send(response);
    });
  });

  user.post('/changePassword', (req, res) => {
    var changepasswordData = req.body;
    var tokendata = req.decoded;
    userService.changePassword(changepasswordData, tokendata, (response) => {
      res.send(response);
    });
  });

  user.post('/logout', (req, res) => { 
    var tokendata = req.decoded;
    console.log(tokendata);
    userService.logout(tokendata, (response) => {
      res.send(response);
    });
  });

  
  user.post('/showAdvertisement', (req, res) => {   
    var tokendata = req.decoded;
    userService.showAdvertisement(tokendata, (response) => {
      res.send(response);
    });
  });

  user.get('/getallcouponlist', (req, res) => {
    userService.getallcouponlist((response) => {
      res.send(response);
    });
  });

  user.post('/getfiltercouponlist', (req, res) => {
    var coupondata = req.body;
    console.log(req.body);
    userService.getfiltercouponlist(coupondata, (response) => {
      res.send(response);
    });
  });

  user.post('/getallcouponlistbycatid', (req, res) => {
    var coupondata = req.body;
    console.log(req.body);
    userService.getallcouponlistByCatId(coupondata, (response) => {
      res.send(response);
    });
  });

  user.post('/getsearchcoupondata', (req, res) => {
    var coupondata = req.body;
    userService.getsearchcoupondata(coupondata, (response) => {
      res.send(response);
    });
  });

  user.post('/postreviewdata', (req, res) => {
    var reviewdata = req.body;
    userService.savereviewdata(reviewdata, (response) => {
      res.send(response);
    });
  });

  user.post('/postreviewdata', (req, res) => {
    var reviewdata = req.body;
    userService.getreviewdata(reviewdata, (response) => {
      res.send(response);
    });
  });

  return user;
}
