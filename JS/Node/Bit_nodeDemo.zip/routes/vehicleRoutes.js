var express = require("express");
var jwt = require('jsonwebtoken');

var vehicleService = require('../services/vehicleService');

var config = require('../config');

var secretKey = config.secretKey;

module.exports = (app, express) => {

  var user = express.Router();

  user.post('/userregister', (req, res) => {
    var registrationData = req.body;
    vehicleService.userregister(registrationData, (response) => {
      res.send(response);
    });
  });

  user.post('/resendemailOTP', (req, res) => {
    var resendOTPData = req.body;
    vehicleService.resendemailOTP(resendOTPData, (response) => {
      res.send(response);
    });
  });

  user.post('/verifyemail', (req, res) => {
    var verifyemailData = req.body;
    vehicleService.verifyemail(verifyemailData, (response) => {
      res.send(response);
    });
  });

  user.post('/login', (req, res) => {
    var loginData = req.body;
    console.log("loginData",loginData);
    vehicleService.login(loginData, (response) => {
      res.send(response);
    });
  });

  // FB Login
  user.post('/fblogin', (req, res) => {
    var loginData = req.body;
    vehicleService.fblogin(loginData, (response) => {
      res.send(response);
    });
  });

  user.post('/forgotpassword', (req, res) => {
    var forgotpasswordData = req.body;
    vehicleService.forgotpassword(forgotpasswordData, (response) => {
      res.send(response);
    });
  });

  user.get('/getcategorydata', (req, res) => {
    vehicleService.getcategorydata((response) => {
      res.send(response);
    });
  });

  //=================
  //Middleware to check token
  //=================

  user.use((req, res, next) => {
    var token = req.body.token || req.param('token') || req.headers['x-access-token'];
    //console.log(token);
    if (token) {
      jwt.verify(token, secretKey, (err, decoded) => {
        if (err) {
          res.status(403).send({
            success: false,
            message: "Authentication failed"
          });
        } else {
          req.decoded = decoded;
          next();
        }
      });
    } else {
      res.status(403).send({
        success: false,
        message: "Authentication token required"
      });
    }
  });

  //=================
  //  Middleware end
  //=================


  user.get('/getprofileData', (req, res) => {
    var tokendata = req.decoded;
    vehicleService.getprofileData(tokendata, (response) => {
      res.send(response);
    });
  });

  user.post('/updateProfile', (req, res) => {
    var updateprofileData = req.body;
    var tokendata = req.decoded;
    vehicleService.updateProfile(updateprofileData, tokendata, (response) => {
      res.send(response);
    });
  });

  user.post('/changePassword', (req, res) => {
    var changepasswordData = req.body;
    var tokendata = req.decoded;
    vehicleService.changePassword(changepasswordData, tokendata, (response) => {
      res.send(response);
    });
  });

  user.post('/logout', (req, res) => { 
    var tokendata = req.decoded;
    console.log(tokendata);
    vehicleService.logout(tokendata, (response) => {
      res.send(response);
    });
  });

  
  user.post('/showAdvertisement', (req, res) => {   
    var tokendata = req.decoded;
    vehicleService.showAdvertisement(tokendata, (response) => {
      res.send(response);
    });
  });

  user.get('/getallcouponlist', (req, res) => {
    vehicleService.getallcouponlist((response) => {
      res.send(response);
    });
  });

  user.post('/getfiltercouponlist', (req, res) => {
    var coupondata = req.body;
    console.log(req.body);
    vehicleService.getfiltercouponlist(coupondata, (response) => {
      res.send(response);
    });
  });

  user.post('/getallcouponlistbycatid', (req, res) => {
    var coupondata = req.body;
    console.log(req.body);
    vehicleService.getallcouponlistByCatId(coupondata, (response) => {
      res.send(response);
    });
  });

  user.post('/getsearchcoupondata', (req, res) => {
    var coupondata = req.body;
    vehicleService.getsearchcoupondata(coupondata, (response) => {
      res.send(response);
    });
  });

  user.post('/postreviewdata', (req, res) => {
    var reviewdata = req.body;
    vehicleService.savereviewdata(reviewdata, (response) => {
      res.send(response);
    });
  });

  user.post('/postreviewdata', (req, res) => {
    var reviewdata = req.body;
    vehicleService.getreviewdata(reviewdata, (response) => {
      res.send(response);
    });
  });

  return user;
}
