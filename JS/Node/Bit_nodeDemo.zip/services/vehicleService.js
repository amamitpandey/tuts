var express = require('express');
var async = require("async");
var validator = require("email-validator");
var randomstring = require("randomstring");
var nodemailer = require('nodemailer');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcrypt-nodejs');
var app = express();
var mongoose = require("mongoose");
var asyncLoop = require('node-async-loop');

var User = require('../models/user');
var EVehicle = require('../models/emergencyvehicle');
var Category = require('../models/category');
var Coupons = require('../models/coupons');
var Reviews = require('../models/reviews');
var Advertisement = require('../models/advertisement');

var config = require("../config");

var siteurl = config.__site_url;

var specialchar = /^[a-zA-Z\s]*$/;

var EmailService = require('../emailfunctions');

var transporter = nodemailer.createTransport('smtps://avijit.team@gmail.com:avijit_team@smtp.gmail.com');

// Create token while sign in
function createToken(user) {
  var tokenData = {
    id: user._id,
    email: user.email.toLowerCase()
  };
  var token = jwt.sign(tokenData, config.secretKey, {
    //expiresIn: '48h'
  });
  return token;
}

var vehicleService = {

  userregister: (registerData, callback) => {
    console.log("registerData", registerData);
    async.waterfall([
      (nextcb) => {
        if (registerData.name == undefined || registerData.name.trim() == '') {
          callback({
            success: false,
            message: "Please enter name"
          });
        } else if (registerData.name.trim() != '' && !specialchar.test(registerData.name)) {
          callback({
            success: false,
            message: "Name can not contain any number or special character"
          });
        } else if (registerData.name.trim() != '' && registerData.name.trim().length > 36) {
          callback({
            success: false,
            message: "Name can not be longer than 36 characters"
          });
        } else if (registerData.address == undefined || registerData.address.trim() == '') {
          callback({
            success: false,
            message: "Please enter address"
          });
        } else if (registerData.mobile == undefined || registerData.mobile.trim() == '') {
          callback({
            success: false,
            message: "Please enter contact number"
          });   
        } else if (registerData.email == undefined || registerData.email.trim() == '' || !validator.validate(registerData.email)) {
          callback({
            success: false,
            message: "Please enter a valid email"
          });
        } else if (registerData.password == undefined || registerData.password == '') {
          callback({
            success: false,
            message: "Please enter a password"
          });
        } else if (registerData.password.length < 6) {
          callback({
            success: false,
            message: "Password length must be minimum 6 characters"
          });
        } else if (registerData.password != registerData.confirm_password) {
          callback({
            success: false,
            message: "Password and confirm password must match"
          });
        } else {
          nextcb(null);
        }
      },

      (nextcb) => {
        User.countDocuments({
          email: registerData.email.toLowerCase()
        }, (err, usercount) => {
          if (err) {
            nextcb(err);
          } else {
            if (usercount > 0) {
              callback({
                status: false,
                message: "Email already registered"
              });
            } else {
              nextcb(null);
            }
          }
        });
      },

      (nextcb) => {
        var user = new User(registerData);
        user.save((err) => {
          if (err) {
            nextcb(err);
          } else {
            nextcb(null, user);           
          }
        });

        //start sent mail
        var mailOptions = {
          from: '"SLAD">', // sender address
          to: registerData.email.toLowerCase(), // list of receivers
          subject: 'SLAD registration success', // Subject line
          html: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head><body bgcolor="#ededed"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ededed" ><tr><td><table width="60%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFF" align="center" style="border-radius:10px; border:1px solid #ededed; box-shadow: 0 0 15px 0 rgba(0, 0, 0, 0.25); margin: auto;"><tr><td valign="top" align="center" style="padding: 15px"><img src="' + siteurl + 'assets/imgs/logo.png" alt="SLAD logo" title="SLAD logo" border=0;/></td><tr><td valign="top" style="padding: 40px;" height="200">Hello ' + registerData.name + ' ,<br><br>Welcome to SLAD. <br><br>You have successfully registered to this App.<br><br>Your email id is <strong>' + registerData.email + ' </strong> and password is <strong>' + registerData.password + ' </strong><br><br> Thank you<br><br>Team SLAD</td></tr><tr><td style="padding: 15px" align="center" bgcolor="#FFF"><p style="font:normal 12px Arial, Helvetica, sans-serif;">Copyright @2018 SLAD, All rights reserved.</p></td></tr></table></td></tr></table></body></html>'
        };

        transporter.sendMail(mailOptions, (err, info) => {
          if (error) {
            console.log(err);
          } else {
            console.log('Mail sent: ' + info.response);
          }
        });
        //end of sent mail
       
      }
    ], (err, userdata) => {
      if (err) {
        callback({
          success: false,
          message: "Some internal error has occured",
          err: err
        });
      }
      else {
        callback({
          success: true,
          message: "Registration Successful.",
          data: userdata
        });
      }
    });
  },

  resendemailOTP: (resendOTPData, callback) => {
    async.waterfall([
      (nextcb) => {
        if (resendOTPData.user_id == undefined || resendOTPData.user_id.trim() == '') {
          callback({
            success: false,
            message: "Some internal error has occured"
          });
        } else {
          nextcb(null);
        }
      },

      (nextcb) => {
        User.findOne({
          _id: resendOTPData.user_id
        }, (err, userdetails) => {
          if (err) {
            nextcb(err);
          } else {
            if (userdetails == null) {
              callback({
                success: false,
                message: "Some internal error has occured"
              });
            } else {

              //start sent mail
              var mailOptions = {
                from: '"SLAD">', // sender address
                to: userdetails.email, // list of receivers
                subject: 'SLAD email varification', // Subject line
                html: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head><body bgcolor="#ededed"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ededed" ><tr><td><table width="60%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFF" align="center" style="border-radius:10px; border:1px solid #ededed; box-shadow: 0 0 15px 0 rgba(0, 0, 0, 0.25); margin: auto;"><tr><td valign="top" align="center" style="padding: 15px"><img src="' + siteurl + 'assets/imgs/logo.png" alt="SLAD logo" title="SLAD logo" border=0;/></td><tr><td valign="top" style="padding: 40px;" height="200">Hello ' + userdetails.firstname + ' ,<br><br>Welcome to SLAD. <br><br> Your email verification OTP is <strong>' + userdetails.emailOTP + '</strong> <br><br> Thank you<br><br>Team SLAD</td></tr><tr><td style="padding: 15px" align="center" bgcolor="#FFF"><p style="font:normal 12px Arial, Helvetica, sans-serif;">Copyright @2018 SLAD, All rights reserved.</p></td></tr></table></td></tr></table></body></html>'
              };

              transporter.sendMail(mailOptions, (err, info) => {
                if (error) {
                  console.log(err);
                } else {
                  console.log('Mail sent: ' + info.response);
                }
              });
              //end of sent mail
              nextcb(null);
            }
          }
        });
      }
    ], (err) => {
      if (err) {
        callback({
          success: false,
          message: "Some internal error has occurred",
          err: err
        });
      } else {
        callback({
          success: true,
          message: "Email verification OTP has been resent to your email"
        });
      }
    });
  },

  verifyemail: (verifyemailData, callback) => {
    async.waterfall([
      (nextcb) => {
        if (verifyemailData.emailOTP == undefined || verifyemailData.emailOTP.trim() == '') {
          callback({
            success: false,
            message: "Invalid email OTP"
          });
        } else if (verifyemailData.user_id == undefined || verifyemailData.user_id.trim() == '') {
          callback({
            success: false,
            message: "Some internal error has occured"
          });
        } else {
          nextcb(null);
        }
      },

      (nextcb) => {
        User.findOne({
          _id: verifyemailData.user_id
        }, (err, userdetails) => {
          if (err) {
            nextcb(err);
          } else {
            if (userdetails == null) {
              callback({
                success: false,
                message: "Some internal error has occured"
              });
            } else {
              if (userdetails.emailOTP != verifyemailData.emailOTP) {
                callback({
                  success: false,
                  message: "Invalid email OTP"
                });
              } else {
                nextcb(null);
              }
            }
          }
        });
      },
      (nextcb) => {
        User.update({
          _id: verifyemailData.user_id
        }, {
            email_verified: true
          }).exec((err, result) => {
            if (err) {
              nextcb(err);
            } else {
              nextcb(null);
            }
          });
      }
    ], (err) => {
      if (err) {
        callback({
          success: false,
          message: "Some internal error has occurred",
          err: err
        });
      } else {
        callback({
          success: true,
          message: "Email verified successfully"
        });
      }
    });
  },

  fblogin: (loginData, callback) => {
    async.waterfall([
      (nextcb) => {
       if (loginData.id == undefined || loginData.id == '') {
          callback({
            success: false,
            message: "Invalid FB Id"
          });
        } else {
          nextcb(null);
        }
      },
      function (nextcb) {
        User.findOne({
          fbid: loginData.id,
          block: false,
          login_type:'fb'
        }, (err, userdetails) => {
          if (err) {
            nextcb(err);
          } else {
            if (userdetails == null) {
                var emailOTP = randomstring.generate({
                  length: 8,
                  charset: 'numeric'
                });

                var generatedpassword = randomstring.generate({
                  length: 6,
                  charset: 'numeric'
                });
        
               // var usernameArr = loginData.name.split(" ");

                loginData.firstname = loginData.first_name;
                loginData.lastname  = loginData.last_name;
                loginData.emailOTP = emailOTP;
                loginData.password = generatedpassword;
                loginData.fbid = loginData.id;
                loginData.login_type = 'fb';

                //console.log(loginData);
        
                var user = new User(loginData);
                user.save((err) => {
                  console.log(user);
                  if (err) {
                    nextcb(err);
                  } else {
                    console.log(user);
                    var token = createToken(user);
                    nextcb(null, token, user);
                  }
                });
              } else {
                var token = createToken(userdetails);
                nextcb(null, token, userdetails);
            }
          }
        });
      }
    ],
      function (err, data, userdetails) {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Login successful",
            token: data,
            user_id: userdetails._id
          });
        }
      });
  },

  login: (loginData, callback) => {
    //console.log(loginData);
    async.waterfall([
      (nextcb) => {
        if (loginData.email == undefined || loginData.email.trim() == '' || !validator.validate(loginData.email)) {
          callback({
            success: false,
            message: "Invalid email"
          });
        } else if (loginData.password == undefined || loginData.password == '' || loginData.password.length < 6) {
          callback({
            success: false,
            message: "Invalid password"
          });
        } else {
          nextcb(null);
        }
      },

      function (nextcb) {
        EVehicle.findOne({
          email: loginData.email.toLowerCase()         
        }, (err, userdetails) => {
          //console.log(userdetails);
          if (err) {
            nextcb(err);
          } else {
            if (userdetails == null) {
              callback({
                success: false,
                message: "Invalid email"
              });
            } else {
              //console.log(userdetails.comparePassword(loginData.password));
              if (!userdetails.comparePassword(loginData.password)) {
                callback({
                  success: false,
                  message: "Invalid password"
                });
              } else {                
                  var token = createToken(userdetails);
                  nextcb(null, token, userdetails);                
              }
            }
          }
        });
      }
    ],
      function (err, data, userdetails) {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Login successful",
            token: data,
            user_id: userdetails._id
          });
        }
      });
  },

  forgotpassword: (forgotpasswordData, callback) => {
    async.waterfall([
      (nextcb) => {
        if (forgotpasswordData.email == undefined || forgotpasswordData.email.trim() == '' || !validator.validate(forgotpasswordData.email)) {
          callback({
            success: false,
            message: "Invalid email"
          });
        } else {
          nextcb(null);
        }
      },
      (nextcb) => {
        EVehicle.count({
          email: forgotpasswordData.email.toLowerCase()
        }, (err, usercount) => {
          if (err) {
            callback({
              success: false,
              message: "Some internal error has occurred",
              err: err
            });
          } else {
            if (usercount == 0) {
              callback({
                success: false,
                message: "Invalid email"
              });
            } else {
              nextcb(null);
            }
          }
        });
      },
      (nextcb) => {
        var newpassword = randomstring.generate({
          length: 6,
          charset: 'numeric'
        });
        bcrypt.hash(newpassword, null, null, function (err, hashedpwd) {
          if (err) {
            nextcb(err);
          } else {
            EVehicle.findOneAndUpdate({
              email: forgotpasswordData.email.toLowerCase()
            }, {
                password: hashedpwd
              }, {
                new: true
              })
              .exec(function (err, userdetails) {
                console.log("userdetails", userdetails);
                if (err) {
                  nextcb(err);
                } else {
                  forgotpasswordData.newpassword = newpassword;
                  EmailService.transitForgotPassword(forgotpasswordData,userdetails);                 
                  nextcb(null);
                }
              });
          }
        });
      }
    ], (err) => {
      if (err) {
        callback({
          success: false,
          message: "Some internal error has occurred",
          err: err
        });
      } else {
        callback({
          success: true,
          message: "Password changed. Please check your email."
        });
      }
    });
  },


  logout: (tokenData,callback) =>{
    EVehicle.update({
      _id: tokenData.id
    },
    {
      devicetoken : '',
      authtoken: ''
    }).exec((err) =>{
       if(err){
        callback({
          status: false,
          message: "Some internal error has occurred",
          err: err
        });
       }else{
          callback({
            success: true,
            message: "You have been successfully logged out"
          });
       }
    })
  },

  getprofileData: (tokenData, callback) => {
    User.findOne({
      _id: tokenData.id
    }, (err, userdetails) => {
      if (err) {
        callback({
          status: false,
          message: "Some internal error has occurred",
          err: err
        });
      } else {
        if (userdetails == null) {
          callback({
            status: false,
            message: "No profile details found"
          });
        } else {
          callback({
            success: true,
            message: "Profile data fetched",
            data: userdetails
          });
        }
      }
    });
  },

  updateProfile: (updateprofileData, tokenData, callback) => {
    async.waterfall([
      (nextcb) => {
        if (updateprofileData.firstname == undefined || updateprofileData.firstname.trim() == '') {
          callback({
            status: false,
            message: "Please enter first name"
          });
        } else if (updateprofileData.firstname.trim() != '' && !specialchar.test(updateprofileData.firstname)) {
          callback({
            status: false,
            message: "First name can not contain any number or special character"
          });
        } else if (updateprofileData.firstname.trim() != '' && updateprofileData.firstname.trim().length > 36) {
          callback({
            status: false,
            message: "First name can not be longer than 36 characters"
          });
        } else if (updateprofileData.lastname == undefined || updateprofileData.lastname.trim() == '') {
          callback({
            status: false,
            message: "Please enter last name"
          });
        } else if (updateprofileData.lastname.trim() != '' && !specialchar.test(updateprofileData.lastname)) {
          callback({
            status: false,
            message: "Last name can not contain any number or special character"
          });
        } else if (updateprofileData.lastname.trim() != '' && updateprofileData.lastname.trim().length > 36) {
          callback({
            status: false,
            message: "Last name can not be longer than 36 characters"
          });
        } else if (updateprofileData.email == undefined || updateprofileData.email.trim() == '' || !validator.validate(updateprofileData.email)) {
          callback({
            status: false,
            message: "Please enter a valid email"
          });
        } else {
          nextcb(null);
        }
      },

      (nextcb) => {
        User.update({
          _id: tokenData.id
        }, {
            firstname: updateprofileData.firstname,
            lastname: updateprofileData.lastname,
            email: updateprofileData.email.toLowerCase()
          }).exec((err, data) => {
            if (err) {
              nextcb(err);
            } else {
              nextcb(null);
            }
          });
      },
    ], (err) => {
      if (err) {
        callback({
          success: false,
          message: "Some internal error has occurred",
          err: err
        });
      } else {
        callback({
          success: true,
          message: "Profile updated successfully"
        });
      }
    });
  },

  changePassword: (changepasswordData, tokenData, callback) => {
    console.log("changepasswordData",changepasswordData);
    async.waterfall([
      (nextcb) => {
        if (changepasswordData.currentpassword == undefined || changepasswordData.currentpassword == '') {
          callback({
            status: false,
            message: "Invalid current password"
          });
        } else if (changepasswordData.currentpassword.length < 6) {
          callback({
            status: false,
            message: "Invalid current password"
          });
        } else if (changepasswordData.newpassword == undefined || changepasswordData.newpassword == '') {
          callback({
            status: false,
            message: "Please enter new password"
          });
        } else if (changepasswordData.newpassword != '' && changepasswordData.newpassword.length < 6) {
          callback({
            status: false,
            message: "Password length must be minimum 6 characters"
          });
        } else if (changepasswordData.currentpassword == changepasswordData.newpassword) {
          callback({
            status: false,
            message: "New password must not be same as current password"
          });
        } else if (changepasswordData.newpassword != changepasswordData.confirmnewpassword) {
          callback({
            status: false,
            message: "New password and confirm new password must match"
          });
        } else {
          nextcb(null);
        }
      },

      (nextcb) => {
        EVehicle.findOne({
          _id: tokenData.id
        }, (err, userdetails) => {
          console.log(userdetails);
          if (err) {
            nextcb(err);
          } else {
            console.log(userdetails);
            if (!userdetails.comparePassword(changepasswordData.currentpassword)) {
              callback({
                status: false,
                message: "Invalid current password"
              });
            } else {
              bcrypt.hash(changepasswordData.newpassword, null, null, (err, hashedpwd) => {
                if (err) {
                  nextcb(err);
                } else {
                  EVehicle.update({
                    _id: tokenData.id
                  }, {
                      password: hashedpwd
                    })
                    .exec((err, data) => {
                      if (err) {
                        nextcb(err);
                      } else {
                        nextcb(null);
                      }
                    });
                }
              });
            }
          }
        })
      },
    ], (err) => {
      if (err) {
        callback({
          success: false,
          message: "Some internal error has occurred",
          err: err
        });
      } else {
        callback({
          success: true,
          message: "Password changed successfully"
        });
      }
    });
  },

  showAdvertisement:(tokenData,callback) =>{
     // Advertisement.find({},(err,adImages) => {
     //  console.log(adImages);
     //   if (err) {
     //      callback({
     //        status: false,
     //        message: "Some internal error has occurred",
     //        err: err
     //      });
     //    } else {
     //      callback({
     //        success: true,
     //        message: "Category data fetched",
     //        data: adImages
     //      });
     //    }
     // });

      var query = Advertisement.find({}).select('ad_image');
        query.exec(function (err, adImages) {
        if (err){
          callback({
            status: false,
            message: "Some internal error has occurred",
            err: err
          });
        }else{
          callback({
            success: true,
            message: "Advertisement data fetched",
            data: adImages
          });
        }        
    });
  },

  getcategorydata: (callback) => {
    Category.find({ block: false }, (err, categorydetails) => {
      if (err) {
        callback({
          status: false,
          message: "Some internal error has occurred",
          err: err
        });
      } else {
        callback({
          success: true,
          message: "Category data fetched",
          data: categorydetails
        });
      }
    });
  },

  getallcouponlist: (callback) => {
    var sort_field = 'createdAt';
    var order = '-1';
    console.log('coupon list hittt');
    Coupons
      .find({})
      .lean()
      .sort([
        [sort_field, order]
      ])
      .exec((err, coupondetails) => {
console.log(coupondetails);
        asyncLoop(coupondetails, function (itm, next) {
          if (itm != '' || itm != undefined) {
                  Reviews.aggregate()
                  .match({coupon_id: mongoose.Types.ObjectId(itm._id)})
                  .group({_id: null,"average": { $avg: "$rating" }})
                  .exec((err, avgrate) => {
                    if (err) {
                      callback({
                        success: false,
                        message: "Some internal error has occurred",
                        err: err
                      });
                    } else {
                      
                      if(avgrate==""){
                        //console.log('hiii');
                        itm['avgvalue'] = 0;
                      }
                      else{
                        //console.log('hello');
                        itm['avgvalue'] = avgrate[0].average;
                       
                      }
                      
                      console.log(JSON.stringify(avgrate));
                     // nextcb(null, coupondetails, reviewdetails, avgrate);
                    }
                    next();
                  });

          } else {
              callback({ success: true, err: err,  message: 'item is not available' })
          }
      }, function () {
        callback({
          success: true,
          message: "Coupon data fetched",
          data: coupondetails,
        });
      });


        // if (err) {
        //   callback({
        //     success: false,
        //     message: "Some internal error has occurred",
        //     err: err
        //   });
        // } else {
        //   callback({
        //     success: true,
        //     message: "Coupon data fetched",
        //     data: coupondetails,
        //   });
        // }
      });
  },

  getfiltercouponlist: (coupondata, callback) => {
      async.waterfall([
        (nextcb) => {
          //console.log(coupondata.coupon_id);
          Coupons.findOne({ _id: coupondata.coupon_id })
          .lean()
          .exec((err, coupondetails) => {
            if (err) {
              callback({
                success: false,
                message: "Some internal error has occurred",
                err: err
              });
            } else {
              nextcb(null, coupondetails);
            }
          });
        },
        (coupondetails,nextcb) => {
          //registerData.emailOTP = emailOTP;
          Reviews.find({coupon_id: coupondata.coupon_id})
          .populate('user_id','firstname lastname')
          .lean()
          .exec((err, reviewdetails) => {
            if (err) {
              callback({
                success: false,
                message: "Some internal error has occurred",
                err: err
              });
            } else {
             // console.log(reviewdetails);
              nextcb(null, coupondetails, reviewdetails);
            }
          });
        },
        (coupondetails,reviewdetails,nextcb) => {
          Reviews.aggregate()
          .match({coupon_id: mongoose.Types.ObjectId(coupondata.coupon_id)})
          .group({_id: null,"average": { $avg: "$rating" }})
          .exec((err, avgrate) => {
            if (err) {
              callback({
                success: false,
                message: "Some internal error has occurred",
                err: err
              });
            } else {
              //console.log(JSON.stringify(avgrate));
              nextcb(null, coupondetails, reviewdetails, avgrate);
            }
          });

        },
      ], (nextcb, coupondetails, reviewdetails, avgrate) => {
          callback({
               success: true,
               message: "Filter coupon details fetched",
               data: coupondetails,
               reviewdata:reviewdetails,
               avg:avgrate
          });
      });
  },

  getsearchcoupondata: (searchData, callback) => {
    Coupons.find({
      $or: [{
        'coupon_name': new RegExp(searchData.details, "i")
      }, {
        'coupon_description': new RegExp(searchData.details, "i")
      }]
    })
      .lean()
      .exec((err, coupondetails) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Search coupon details fetched",
            data: coupondetails
          });
        }
      });
  },

  savereviewdata: (reviewdata, callback)=>{
    console.log(reviewdata);
    async.waterfall([
      (nextcb) => {
        if (reviewdata.review_title == undefined || reviewdata.review_title.trim() == '') {
          callback({
            status: false,
            message: "Please enter title!"
          });
        } else if (reviewdata.review_description.trim() == undefined || reviewdata.review_description.trim() == '') {
          callback({
            status: false,
            message: "Please enter Description!"
          });
        } else if (reviewdata.rating == 0) {
          callback({
            status: false,
            message: "Please select rating!"
          });
        } else {
          nextcb(null);
        }
      },
      (nextcb) => {
        //registerData.emailOTP = emailOTP;
//console.log(reviewdata);
        var review = new Reviews(reviewdata);
        review.save((err) => {
          if (err) {
            nextcb(err);
          } else {
            nextcb(null, review);
          }
        });
      },
    ], (err) => {
      if (err) {
        callback({
          success: false,
          message: "Some internal error has occurred",
          err: err
        });
      } else {
        callback({
          success: true,
          message: "Review has submitted successfuly!"
        });
      }
    });
  },

  // get all review data of the coupon

  getAllReviewListByCoupon: (reviewdata, callback) => {
    Reviews.find({coupon_id: reviewdata.coupon_id })
      .lean()
      .exec((err, coupondetails) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Filter coupon details fetched",
            data: coupondetails
          });
        }
      });
  },


  // get all coupon list by category id

  getallcouponlistByCatId: (coupondata, callback) => {
    var sort_field = 'createdAt';
    var order = '-1';
    console.log('coupon list hittt');
    Coupons
      .find({category_id: mongoose.Types.ObjectId(coupondata.catid)})
      .lean()
      .sort([
        [sort_field, order]
      ])
      .exec((err, coupondetails) => {
       console.log(coupondetails);
       if(coupondetails.length>0){
        asyncLoop(coupondetails, function (itm, next) {
          if (itm != '' || itm != undefined) {
                  Reviews.aggregate()
                  .match({coupon_id: mongoose.Types.ObjectId(itm._id)})
                  .group({_id: null,"average": { $avg: "$rating" }})
                  .exec((err, avgrate) => {
                    if (err) {
                      callback({
                        success: false,
                        message: "Some internal error has occurred",
                        err: err
                      });
                    } else {
                      
                      if(avgrate==""){
                        //console.log('hiii');
                        itm['avgvalue'] = 0;
                      }
                      else{
                        //console.log('hello');
                        itm['avgvalue'] = avgrate[0].average;
                       
                      }
                      
                      console.log(JSON.stringify(avgrate));
                     // nextcb(null, coupondetails, reviewdetails, avgrate);
                    }
                    next();
                  });

          } else {
              callback({ success: true, err: err,  message: 'item is not available' })
          }
      }, function () {
        callback({
          success: true,
          message: "Coupon data fetched",
          data: coupondetails,
        });
      });


        // if (err) {
        //   callback({
        //     success: false,
        //     message: "Some internal error has occurred",
        //     err: err
        //   });
        // } else {
        //   callback({
        //     success: true,
        //     message: "Coupon data fetched",
        //     data: coupondetails,
        //   });
        // }
         }
         else{
          callback({
            success: true,
            message: "No coupon data found!",
            data: [],
          });
         }
      });
  },

};
module.exports = vehicleService;
