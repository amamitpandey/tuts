var express = require('express');
var jwt = require('jsonwebtoken');
var async = require("async");
var validator = require("email-validator");
var nodemailer = require('nodemailer');
var bcrypt = require('bcrypt-nodejs');
var multer = require('multer');
var app = express();

var Admin = require('../models/admin');
var User = require('../models/user');
var EVehicle = require('../models/emergencyvehicle');
var Advertisement = require('../models/advertisement');
var Coupons = require('../models/coupons');

var config = require("../config");

require('mongoose-pagination');

var siteurl = config.__site_url;
var specialchar = /^[a-zA-Z\s]*$/;

var EmailService = require('../emailfunctions');

var transporter = nodemailer.createTransport('smtps://avijit.team@gmail.com:avijit_team@smtp.gmail.com');

//Create token while sign in

function createToken(admin) {
  var tokenData = {
    id: admin._id,
    email: admin.email.toLowerCase()
  };
  var token = jwt.sign(tokenData, config.secretKey, {
    expiresIn: '48h'
  });
  return token;
}

var adminService = {

  adminregistration: (registerData, imagedata, callback) => {
    async.waterfall([
      (nextcb) => {
        if (registerData.firstname == undefined || registerData.firstname.trim() == '') {
          callback({
            status: false,
            message: "Please enter first name"
          });
        } else if (registerData.firstname.trim() != '' && !specialchar.test(registerData.firstname)) {
          callback({
            status: false,
            message: "First name can not contain any number or special character"
          });
        } else if (registerData.firstname.trim() != '' && registerData.firstname.trim().length > 36) {
          callback({
            status: false,
            message: "First name can not be longer than 36 characters"
          });
        } else if (registerData.lastname == undefined || registerData.lastname.trim() == '') {
          callback({
            status: false,
            message: "Please enter last name"
          });
        } else if (registerData.lastname.trim() != '' && !specialchar.test(registerData.lastname)) {
          callback({
            status: false,
            message: "Last name can not contain any number or special character"
          });
        } else if (registerData.lastname.trim() != '' && registerData.lastname.trim().length > 36) {
          callback({
            status: false,
            message: "Last name can not be longer than 36 characters"
          });
        } else if (registerData.email == undefined || registerData.email.trim() == '' || !validator.validate(registerData.email)) {
          callback({
            status: false,
            message: "Please enter a valid email"
          });
        } else if (registerData.password == undefined || registerData.password == '') {
          callback({
            status: false,
            message: "Please enter a password"
          });
        } else if (registerData.password.length < 6) {
          callback({
            status: false,
            message: "Password length must be minimum 6 characters"
          });
        } else if (registerData.password != registerData.confirmpassword) {
          callback({
            status: false,
            message: "Password and confirm password must match"
          });
        } else {
          nextcb(null);
        }
      },

      (nextcb) => {
        Admin.count({
          email: registerData.email.toLowerCase()
        }, (err, admincount) => {
          if (err) {
            nextcb(err);
          } else {
            if (admincount > 0) {
              callback({
                status: false,
                message: "Email already registered"
              });
            } else {
              nextcb(null);
            }
          }
        });
      },

      (nextcb) => {
        if (imagedata != undefined) {
          var file = imagedata.profileimage;

          var ext = file.name.slice(file.name.lastIndexOf('.'));
          var fileName = Date.now() + ext;
          var folderpath = 'assets/profileimage/';

          file.mv(folderpath + fileName, (err) => {
            if (err) {
              console.log(err);
            }
          });
        } else {
          fileName = 'default.jpg';
        }

        registerData.profileimage = fileName;

        var admin = new Admin(registerData);
        admin.save((err) => {
          if (err) {
            nextcb(err);
          } else {
            nextcb(null);
          }
        });
      }
    ], (err) => {
      if (err) {
        callback({
          success: false,
          message: "Some internal error has occured",
          err: err
        });
      }
      else {
        callback({
          success: true,
          message: "Registration Successful"
        });
      }
    });
  },

  login: (loginData, callback) => {
    async.waterfall([
      (nextcb) => {
        if (loginData.email == undefined || loginData.email.trim() == '' || !validator.validate(loginData.email)) {
          callback({
            success: false,
            message: "Invalid email"
          });
        } else if (loginData.password == undefined || loginData.password == '' || loginData.password.length < 6) {
          callback({
            success: false,
            message: "Invalid password"
          });
        } else {
          nextcb(null);
        }
      },

      (nextcb) => {
        Admin.findOne({
          email: loginData.email.toLowerCase()
        }, (err, admindetails) => {
          if (err) {
            nextcb(err);
          } else {
            if (admindetails == null) {
              callback({
                success: false,
                message: "Invalid email"
              });
            } else {
              if (!admindetails.comparePassword(loginData.password)) {
                callback({
                  success: false,
                  message: "Invalid password"
                });
              } else {
                var token = createToken(admindetails);
                nextcb(null, token);
              }
            }
          }
        });
      }
    ],
      (err, data) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Login successful",
            token: data
          });
        }
      });
  },

addEmergencyVehicle: (vehicleData, callback) => {
    async.waterfall([
      (nextcb) => {
        if (vehicleData.vehicle_no == undefined || vehicleData.vehicle_no.trim() == '') {
          callback({
            status: false,
            message: "Please enter vehicle number"
          });        
        } else if (vehicleData.email == undefined || vehicleData.email.trim() == '' || !validator.validate(vehicleData.email)) {
          callback({
            status: false,
            message: "Please enter a valid email"
          });
        } else if (vehicleData.password == undefined || vehicleData.password == '') {
          callback({
            status: false,
            message: "Please enter a password"
          });
        } else if (vehicleData.password.length < 6) {
          callback({
            status: false,
            message: "Password length must be minimum 6 characters"
          });
        } else if (vehicleData.password != vehicleData.confirmpassword) {
          callback({
            status: false,
            message: "Password and confirm password must match"
          });
        } else {
          nextcb(null);
        }
      },

      (nextcb) => {
        EVehicle.count({
          email: vehicleData.email.toLowerCase()
        }, (err, admincount) => {
          if (err) {
            nextcb(err);
          } else {
            if (admincount > 0) {
              callback({
                status: false,
                message: "Email already registered"
              });
            } else {
              nextcb(null);
            }
          }
        });
      },

      (nextcb) => {        

        var eVehicle = new EVehicle(vehicleData);
        eVehicle.save((err) => {
          if (err) {
            nextcb(err);
          } else {
            EmailService.EVehicleRegistration(vehicleData)
            nextcb(null);
          }
        });
      }
    ], (err) => {
      if (err) {
        callback({
          success: false,
          message: "Some internal error has occured",
          err: err
        });
      }
      else {
        callback({
          success: true,
          message: "Emergency Vehicle Added Successful"
        });
      }
    });
  },

  sendpasswordlink: (sendpasswordlinkData, callback) => {
    async.waterfall([
      (nextcb) => {
        if (sendpasswordlinkData.email == undefined || sendpasswordlinkData.email.trim() == '' || !validator.validate(sendpasswordlinkData.email)) {
          callback({
            success: false,
            message: "Invalid email"
          });
        }
        else {
          nextcb(null);
        }
      },
      (nextcb) => {
        Admin.findOne({
          email: sendpasswordlinkData.email.toLowerCase()
        }, (err, admindetails) => {
          if (err) {
            nextcb(err);
          } else {
            if (admindetails == null) {
              callback({
                status: false,
                message: "Invalid email"
              });
            } else {
              var mailOptions = {
                from: '"FrasGo">',
                to: admindetails.email,
                subject: 'FrasGo forgot password',
                html: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head><body bgcolor="#ededed"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ededed" ><tr><td><table width="60%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFF" align="center" style="border-radius:10px; border:1px solid #ededed; box-shadow: 0 0 15px 0 rgba(0, 0, 0, 0.25); margin: auto;"><tr><td valign="top" align="center" style="padding: 15px"><img style="width: 60%" src="' + siteurl + 'assets/imgs/logo.png" alt="FrasGo logo" title="FrasGo logo" border=0;/></td><tr><td valign="top" style="padding: 40px;" height="200">Hello ' + admindetails.firstname + ' ' + admindetails.lastname + ' ,<br><br>Forgot your password! No big deal, we all forgot sometimes.<br><br> Click on the below link for new password <br><br><a href="' + config.__baseurl + 'newpassword/' + admindetails._id + '">Click here</a> <br><br> Thank you<br><br>Team FrasGo</td></tr><tr><td style="padding: 15px" align="center" bgcolor="#FFF"><p style="font:normal 12px Arial, Helvetica, sans-serif;">Copyright @2018 FrasGo, All rights reserved.</p></td></tr></table></td></tr></table></body></html>'
              };

              transporter.sendMail(mailOptions, (err, info) => {
                if (err) {
                  console.log(err);
                } else {
                  console.log('Mail sent: ' + info.response);
                }
              });

              nextcb(null);
            }
          }
        });
      }
    ],
      (err) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Please check your email for new password link"
          });
        }
      });

  },

  newpassword: (forgotpassData, callback) => {
    async.waterfall([
      (nextcb) => {
        if (forgotpassData.id == undefined || forgotpassData.id == '') {
          callback({
            success: false,
            message: "Invalid admin id"
          });
        } else if (forgotpassData.newpassword == undefined || forgotpassData.newpassword == '') {
          callback({
            success: false,
            message: "Please enter a new password"
          });
        } else if (forgotpassData.newpassword.length < 6) {
          callback({
            success: false,
            message: "Password must be minimum 6 characters"
          });
        } else if (forgotpassData.newpassword != forgotpassData.confirmnewpassword) {
          callback({
            success: false,
            message: "New password and confirm new password must match"
          });
        } else {
          nextcb(null);
        }
      },
      (nextcb) => {
        Admin.count({
          _id: forgotpassData.id
        }, (err, admincount) => {
          if (err) {
            nextcb(err);
          } else {
            if (admincount != 0) {
              nextcb(null);
            } else {
              callback({
                success: false,
                message: "Invalid admin id"
              });
            }
          }
        })
      },
      (nextcb) => {
        Admin.findOne({
          _id: forgotpassData.id
        }, (err, admindetails) => {
          if (err) {
            nextcb(err);
          } else {
            bcrypt.hash(forgotpassData.newpassword, null, null, function (err, hashedpwd) {
              if (err) {
                nextcb(err);
              } else {
                Admin.update({
                  _id: forgotpassData.id
                }, {
                    password: hashedpwd
                  })
                  .exec((err, data) => {
                    if (err) {
                      nextcb(err);
                    } else {
                      nextcb(null);
                    }
                  });
              }
            });
          }
        })
      }
    ],
      (err) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Password changed successfully"
          });
        }
      });
  },

  getprofiledata: (tokenData, callback) => {
    console.log(tokenData);
    Admin.findOne({
      _id: tokenData.id
    }, (err, admindetails) => {
      console.log(admindetails);
      if (err) {
        callback({
          status: false,
          message: "Some internal error has occurred",
          err: err
        });
      } else {
        if (admindetails == null) {
          callback({
            status: false,
            message: "Some internal error has occurred"
          });
        } else {
          callback({
            success: true,
            message: "Profile data fetched",
            data: admindetails
          });
        }
      }
    });
  },

  updateprofile: (updateprofileData, imagedata, tokenData, callback) => {
    async.waterfall([
      (nextcb) => {
        if (updateprofileData.firstname == undefined || updateprofileData.firstname.trim() == '') {
          callback({
            status: false,
            message: "Please enter first name"
          });
        } else if (updateprofileData.firstname.trim() != '' && !specialchar.test(updateprofileData.firstname)) {
          callback({
            status: false,
            message: "First name can not contain any number or special character"
          });
        } else if (updateprofileData.firstname.trim() != '' && updateprofileData.firstname.trim().length > 36) {
          callback({
            status: false,
            message: "First name can not be longer than 36 characters"
          });
        } else if (updateprofileData.lastname == undefined || updateprofileData.lastname.trim() == '') {
          callback({
            status: false,
            message: "Please enter last name"
          });
        } else if (updateprofileData.lastname.trim() != '' && !specialchar.test(updateprofileData.lastname)) {
          callback({
            status: false,
            message: "Last name can not contain any number or special character"
          });
        } else if (updateprofileData.lastname.trim() != '' && updateprofileData.lastname.trim().length > 36) {
          callback({
            status: false,
            message: "Last name can not be longer than 36 characters"
          });
        } else if (updateprofileData.email == undefined || updateprofileData.email.trim() == '' || !validator.validate(updateprofileData.email)) {
          callback({
            status: false,
            message: "Please enter a valid email"
          });
        } else {
          nextcb(null);
        }
      },

      (nextcb) => {
        if (imagedata != undefined) {
          var file = imagedata.profileimage;

          var ext = file.name.slice(file.name.lastIndexOf('.'));
          var fileName = Date.now() + ext;
          var folderpath = 'assets/profileimage/';

          file.mv(folderpath + fileName, (err) => {
            if (err) {
              console.log(err);
            }
          });

          Admin.update({
            _id: tokenData.id
          }, {
              firstname: updateprofileData.firstname,
              lastname: updateprofileData.lastname,
              email: updateprofileData.email.toLowerCase(),
              profileimage: fileName
            }).exec((err, data) => {
              if (err) {
                nextcb(err);
              } else {
                nextcb(null);
              }
            });
        } else {
          Admin.update({
            _id: tokenData.id
          }, {
              firstname: updateprofileData.firstname,
              lastname: updateprofileData.lastname,
              email: updateprofileData.email.toLowerCase()
            }).exec((err, data) => {
              if (err) {
                nextcb(err);
              } else {
                nextcb(null);
              }
            });
        }
      },
    ], (err) => {
      if (err) {
        callback({
          success: false,
          message: "Some internal error has occurred",
          err: err
        });
      } else {
        callback({
          success: true,
          message: "Profile updated successfully"
        });
      }
    });
  },

  changepassword: (changepasswordData, tokenData, callback) => {
    async.waterfall([
      (nextcb) => {
        if (changepasswordData.currentpassword == undefined || changepasswordData.currentpassword == '') {
          callback({
            status: false,
            message: "Invalid current password"
          });
        } else if (changepasswordData.currentpassword.length < 6) {
          callback({
            status: false,
            message: "Invalid current password"
          });
        } else if (changepasswordData.newpassword == undefined || changepasswordData.newpassword == '') {
          callback({
            status: false,
            message: "Please enter new password"
          });
        } else if (changepasswordData.newpassword != '' && changepasswordData.newpassword.length < 6) {
          callback({
            status: false,
            message: "Password length must be minimum 6 characters"
          });
        } else if (changepasswordData.currentpassword == changepasswordData.newpassword) {
          callback({
            status: false,
            message: "New password must not be same as current password"
          });
        } else if (changepasswordData.newpassword != changepasswordData.confirmnewpassword) {
          callback({
            status: false,
            message: "New password and confirm new password must match"
          });
        } else {
          nextcb(null);
        }
      },

      (nextcb) => {
        Admin.findOne({
          _id: tokenData.id
        }, (err, admindetails) => {
          if (err) {
            nextcb(err);
          } else {
            if (!admindetails.comparePassword(changepasswordData.currentpassword)) {
              callback({
                status: false,
                message: "Invalid current password"
              });
            } else {
              bcrypt.hash(changepasswordData.newpassword, null, null, (err, hashedpwd) => {
                if (err) {
                  nextcb(err);
                } else {
                  Admin.update({
                    _id: tokenData.id
                  }, {
                      password: hashedpwd
                    })
                    .exec((err, data) => {
                      if (err) {
                        nextcb(err);
                      } else {
                        nextcb(null);
                      }
                    });
                }
              });
            }
          }
        })
      },
    ], (err) => {
      if (err) {
        callback({
          success: false,
          message: "Some internal error has occurred",
          err: err
        });
      } else {
        callback({
          success: true,
          message: "Password changed successfully"
        });
      }
    });
  },

  getalluserdetails: (pagenum, callback) => {
    var page = 1;
    var limit = 10;
    var sort_field = 'createdAt';
    var order = '-1';

    page = pagenum;

    User
      .find({})
      .sort([
        [sort_field, order]
      ])
      .paginate(page, limit, (err, userdetails) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          User
            .count({})
            .exec((err, usercount) => {
              if (err) {
                callback({
                  success: false,
                  message: "Some internal error has occurred",
                  err: err
                });
              } else {
                callback({
                  success: true,
                  message: "All user details fetched",
                  data: userdetails,
                  usercount: usercount
                });
              }
            });
        }
      });
  },


  addAdvertise:(addAdvertiseFiles,tokenData,callback) =>{
    console.log("addAdvertiseData",addAdvertiseFiles);

    if(addAdvertiseFiles ==null){
      callback({
          success:false,
          message: "No image selected."
        })
    }else{

     // ==================MULTER IMPLEMENTATION=========================
      // var storage = multer.diskStorage({
      //   destination: function (req, file, callback) {
      //     console.log("destination",req.files);
      //     callback(null, 'assets/advertiseImgs/');
      //   },
      //   filename: function (req, file, callback) {
      //     console.log("upload",upload);
      //     callback(null, file.fieldname + '-' + Date.now());
      //   }
      // });

      // var upload = multer({ storage : storage });
      // console.log("upload",upload);

      // ==================MULTER IMPLEMENTATION=========================
      //let advertiseImgArray = [];
       var upload;    // Object.values(addAdvertiseFiles) converts obj to array of the elements of obj
       Object.values(addAdvertiseFiles).forEach(function(value,index){
         console.log(value);
        
          var file = value;
          var ext = file.name.slice(file.name.lastIndexOf('.'));
          var fileName = Date.now() + ext;
          var folderpath = 'assets/advertiseImgs/';

          file.mv(folderpath + fileName, (err) => {
            if (err) {
              console.log(err);
              console.log("file up",upload);
              upload = false;
            }else{
              let adData = {
               ad_image : fileName
              }
              var advertisement = new Advertisement(adData);
              advertisement.save((err) => {
                if (!err) {             
                 upload = true;
                     callback({
                    success:true,
                    message: "Advertisement added."
                  })
                 // console.log("file save no err",upload);
                } else {
                 upload =false; 
                   callback({
                    success:false,
                    message: "Error in adding advertisement."
                  })
                  //  console.log("file save no err",upload);            
                }
              });
            }
          });                 
        });
       // console.log("last1",upload); 
         //if(upload == true){   
         //   console.log("last",upload);     
            callback({
              success:true,
              message: "Advertisement added."
            })
       //   }else{
            // console.log("last",upload); 
            //  callback({
            //   success:false,
            //   message: "Error in adding advertisement.",              
            // })
         // }
      }

      //  let ad_image = JSON.stringify(advertiseImgArray);     

       // console.log("adlogo",ad_image); 
        // let adData = {
        //   ad_image : ad_image
        // }

  },

  getsearchuserData: (userdata, callback) => {
    User.find({
      $or: [{
        'firstname': new RegExp(userdata.details, "i")
      }, {
        'lastname': new RegExp(userdata.details, "i")
      }, {
        'email': new RegExp(userdata.details, "i")
      }]
    })
      .exec((err, userdetails) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Search user details fetched",
            data: userdetails
          });
        }
      });
  },

  blockuser: (userdata, callback) => {
    if (userdata._id == undefined || userdata._id == '') {
      callback({
        success: false,
        message: "Invalid user Id"
      });
    } else {
      User.update({
        _id: userdata._id
      }, {
          block: true
        })
        .exec((err, data) => {
          if (err) {
            callback({
              success: false,
              message: "Some internal error has occurred",
              err: err
            });
          } else {
            callback({
              success: true,
              message: "User blocked"
            });
          }
        });
    }
  },

  unblockuser: (userdata, callback) => {
    if (userdata._id == undefined || userdata._id == '') {
      callback({
        success: false,
        message: "Invalid user Id"
      });
    } else {
      User.update({
        _id: userdata._id
      }, {
          block: false
        })
        .exec((err, data) => {
          if (err) {
            callback({
              success: false,
              message: "Some internal error has occurred",
              err: err
            });
          } else {
            callback({
              success: true,
              message: "User unblocked"
            });
          }
        });
    }
  },

  removeuser: (userdata, callback) => {
    if (userdata._id == undefined || userdata._id == '') {
      callback({
        success: false,
        message: "Invalid user Id"
      });
    } else {
      User.remove({
        _id: userdata._id
      })
        .exec((err, data) => {
          if (err) {
            callback({
              success: false,
              message: "Some internal error has occurred",
              err: err
            });
          } else {
            callback({
              success: true,
              message: "User removed successfully"
            });
          }
        });
    }
  },

  getoneuserData: (userid, callback) => {
    User.findOne({
      _id: userid
    })
      .exec((err, userdetails) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          if (userdetails == null) {
            callback({
              success: false,
              message: "Some internal error has occurred"
            });
          } else {
            callback({
              success: true,
              message: "User data fetched",
              data: userdetails
            });
          }
        }
      });
  },

  updateuser: (userdata, callback) => {
    async.waterfall([
      (nextcb) => {
        if (userdata.firstname == undefined || userdata.firstname.trim() == '') {
          callback({
            status: false,
            message: "Please enter first name"
          });
        } else if (userdata.firstname.trim() != '' && !specialchar.test(userdata.firstname)) {
          callback({
            status: false,
            message: "First name can not contain any number or special character"
          });
        } else if (userdata.firstname.trim() != '' && userdata.firstname.trim().length > 36) {
          callback({
            status: false,
            message: "First name can not be longer than 36 characters"
          });
        } else if (userdata.lastname == undefined || userdata.lastname.trim() == '') {
          callback({
            status: false,
            message: "Please enter last name"
          });
        } else if (userdata.lastname.trim() != '' && !specialchar.test(userdata.lastname)) {
          callback({
            status: false,
            message: "Last name can not contain any number or special character"
          });
        } else if (userdata.lastname.trim() != '' && userdata.lastname.trim().length > 36) {
          callback({
            status: false,
            message: "Last name can not be longer than 36 characters"
          });
        } else if (userdata.email == undefined || userdata.email.trim() == '' || !validator.validate(userdata.email)) {
          callback({
            status: false,
            message: "Please enter a valid email"
          });
        } else {
          nextcb(null);
        }
      },

      (nextcb) => {
        User.update({
          _id: userdata.id
        }, {
            firstname: userdata.firstname,
            lastname: userdata.lastname
          }).exec((err, data) => {
            if (err) {
              nextcb(err);
            } else {
              nextcb(null);
            }
          });
      },
    ], (err) => {
      if (err) {
        callback({
          success: false,
          message: "Some internal error has occurred",
          err: err
        });
      } else {
        callback({
          success: true,
          message: "Profile updated successfully"
        });
      }
    });
  },

  addcategory: (categoryData, callback) => {
    async.waterfall([
      (nextcb) => {
        if (categoryData.category_name == undefined || categoryData.category_name.trim() == '') {
          callback({
            success: false,
            message: "Please enter category name"
          });
        } else if (categoryData.category_icon == undefined || categoryData.category_icon.trim() == '') {
          callback({
            success: false,
            message: "Please select an icon"
          });
        } else {
          nextcb(null);
        }
      },
      (nextcb) => {
        Category.count({
          category_name: categoryData.category_name
        }, (err, categorycount) => {
          if (err) {
            nextcb(err);
          } else {
            if (categorycount > 0) {
              callback({
                status: false,
                message: "Category already exists"
              });
            } else {
              nextcb(null);
            }
          }
        });
      },
      (nextcb) => {
        var category = new Category(categoryData);
        category.save((err) => {
          if (err) {
            nextcb(err);
          } else {
            nextcb(null);
          }
        });
      }
    ], (err) => {
      if (err) {
        callback({
          success: false,
          message: "Some internal error has occurred",
          err: err
        });
      } else {
        callback({
          success: true,
          message: "Category added successfully"
        });
      }
    });

  },

  getcategorydata: (pagenum, callback) => {
    var page = 1;
    var limit = 10;
    var sort_field = 'createdAt';
    var order = '-1';

    page = pagenum;

    Category
      .find({})
      .lean()
      .sort([
        [sort_field, order]
      ])
      .paginate(page, limit, (err, categorydetails) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
        Category
          .count({})
          .exec(function (err, categorycount) {
            if (err) {
              callback({
                status: false,
                message: "Some internal error has occurred",
                err: err
              });
            } else {
              callback({
                success: true,
                message: "Category data fetched",
                data: categorydetails,
                categorycount: categorycount
              });
            }
          });
        }
      });
  },

  getsearchcategorydata: (searchData, callback) => {
    Category.find({
      $or: [{
        'category_name': new RegExp(searchData.details, "i")
      }]
    })
      .lean()
      .exec((err, categorydetails) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Search category details fetched",
            data: categorydetails
          });
        }
      });
  },

  blockcategory: (categorydata, callback) => {
    Category.update({
      _id: categorydata._id
    }, {
        block: true
      })
      .exec((err, data) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Category blocked"
          });
        }
      });
  },

  unblockcategory: (categorydata, callback) => {
    Category.update({
      _id: categorydata._id
    }, {
        block: false
      })
      .exec((err, data) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Category unblocked"
          });
        }
      });
  },

  getonecategorydata: (categoryid, callback) => {
    Category.findOne({
      _id: categoryid
    })
      .exec((err, categorydetails) => {
        if (err) {
          callback({
            status: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          if (categorydetails == null) {
            callback({
              status: false,
              message: "Some internal error has occurred"
            });
          } else {
            callback({
              success: true,
              message: "Category data fetched",
              data: categorydetails
            });
          }
        }
      });
  },

  updatecategory: (categorydata, callback) => {
    async.waterfall([
      (nextcb) => {
        if (categorydata.category_name == undefined || categorydata.category_name.trim() == '') {
          callback({
            success: false,
            message: "Please enter category name"
          });
        } else if (categorydata.category_icon == undefined || categorydata.category_icon.trim() == '') {
          callback({
            success: false,
            message: "Please select an icon"
          });
        } else {
          nextcb(null);
        }
      },
      (nextcb) => {
        Category.count({
          category_name: categorydata.category_name
        }, (err, categorycount) => {
          if (err) {
            nextcb(err);
          } else {
            if (categorycount > 0) {
              callback({
                status: false,
                message: "Category name already exists"
              });
            } else {
              nextcb(null);
            }
          }
        });
      },
      (nextcb) => {
        Category.update({
          _id: categorydata.category_id
        }, {
            category_name: categorydata.category_name,
            category_icon: categorydata.category_icon
          }).exec((err, data) => {
            if (err) {
              nextcb(err);
            } else {
              nextcb(null);
            }
          });
      }
    ],
      (err) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Category updated successfully"
          });
        }
      });
  },

  removecategory: (categorydata, callback) => {
    if (categorydata.category_id == undefined || categorydata.category_id == '') {
      callback({
        success: false,
        message: "Invalid category Id"
      });
    } else {
      Category.remove({
        _id: categorydata.category_id
      })
        .exec((err) => {
          if (err) {
            callback({
              success: false,
              message: "Some internal error has occurred",
              err: err
            });
          } else {
            callback({
              success: true,
              message: "Category removed successfully"
            });
          }
        });
    }
  },

  addcoupons: (coupondata, imagedata, callback) => {
    async.waterfall([
      (nextcb) => {
        if (coupondata.category_id == undefined || coupondata.category_id == '') {
          callback({
            success: false,
            message: "Please select a category"
          });
        } else if (coupondata.coupon_name == undefined || coupondata.coupon_name == '') {
          callback({
            success: false,
            message: "Please enter coupon name"
          });
        } else if (coupondata.coupon_description == undefined || coupondata.coupon_description == '') {
          callback({
            success: false,
            message: "Please enter coupon description"
          });
        } else if (coupondata.barcode_id == undefined || coupondata.barcode_id == '') {
          callback({
            success: false,
            message: "Please enter barcode Id"
          });
        } else if (coupondata.original_price == undefined || coupondata.original_price == '') {
          callback({
            success: false,
            message: "Please enter original price"
          });
        } else if (coupondata.discount_percent == undefined || coupondata.discount_percent == '') {
          callback({
            success: false,
            message: "Please enter discount percentage"
          });
        } else if (coupondata.discount_price == undefined || coupondata.discount_price == '') {
          callback({
            success: false,
            message: "Please enter discount price"
          });
        }
        else if (coupondata.cashback_percent == undefined || coupondata.cashback_percent == '') {
          callback({
            success: false,
            message: "Please enter cashback percent"
          });
        }
        else if (coupondata.address == undefined || coupondata.address == '') {
          callback({
            success: false,
            message: "Please enter coupon address"
          });
        } else if (coupondata.address_lat == undefined || coupondata.address_lat == '') {
          callback({
            success: false,
            message: "Invalid Address"
          });
        } else if (coupondata.address_long == undefined || coupondata.address_long == '') {
          callback({
            success: false,
            message: "Invalid Address"
          });
        } else if (coupondata.expire_date == undefined || coupondata.address_long == '') {
          callback({
            success: false,
            message: "Please select an expire date"
          });
        } else {
          nextcb(null);
        }
      },

      (nextcb) => {
        Coupons.count({
          coupon_name: coupondata.coupon_name
        }, (err, couponcount) => {
          if (err) {
            nextcb(err);
          } else {
            if (couponcount > 0) {
              callback({
                status: false,
                message: "Coupon name already exists"
              });
            } else {
              nextcb(null);
            }
          }
        });
      },

      (nextcb) => {
        if (imagedata.coupon_image != undefined || imagedata.coupon_image != null) {
          var file = imagedata.coupon_image;
          var ext = file.name.slice(file.name.lastIndexOf('.'));
          var fileName = Date.now() + ext;
          var folderpath = 'assets/couponimage/';
          file.mv(folderpath + fileName, function (err) {
            if (err) {
              console.log(err);
            }
          });
          coupondata.coupon_image = fileName;
          nextcb(null);
        } else {
          coupondata.coupon_image = 'defaultcoupon.png';
          nextcb(null);
        }
      },

      (nextcb) => {
        if (imagedata.barcode_image != undefined || imagedata.barcode_image != null) {
          var file = imagedata.barcode_image;
          var ext = file.name.slice(file.name.lastIndexOf('.'));
          var fileName = Date.now() + ext;
          var folderpath = 'assets/barcodeimage/';
          file.mv(folderpath + fileName, function (err) {
            if (err) {
              console.log(err);
            }
          });
          coupondata.barcode_image = fileName;
          nextcb(null);
        } else {
          callback({
            status: false,
            message: "Please select barcode image"
          });
        }
      },

      (nextcb) => {
        var coupons = new Coupons(coupondata);
        coupons.save((err) => {
          if (err) {
            nextcb(err);
          } else {
            nextcb(null);
          }
        });
      }
    ], (err) => {
      if (err) {
        callback({
          success: false,
          message: "Some internal error has occurred",
          err: err
        });
      } else {
        callback({
          success: true,
          message: "Coupon added successfully"
        });
      }
    })

  },

  getcouponlist: (pagenum, callback) => {
    var page = 1;
    var limit = 10;
    var sort_field = 'createdAt';
    var order = '-1';

    page = pagenum;

    Coupons
      .find({})
      .lean()
      .sort([
        [sort_field, order]
      ])
      .paginate(page, limit, (err, coupondetails) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
        Coupons
          .count({})
          .exec(function (err, couponcount) {
            if (err) {
              callback({
                status: false,
                message: "Some internal error has occurred",
                err: err
              });
            } else {
              callback({
                success: true,
                message: "Coupon data fetched",
                data: coupondetails,
                couponcount: couponcount
              });
            }
          });
        }
      });
  },

  getsearchcoupondata: (searchData, callback) => {
    Coupons.find({
      $or: [{
        'coupon_name': new RegExp(searchData.details, "i")
      }, {
        'coupon_description': new RegExp(searchData.details, "i")
      }]
    })
      .lean()
      .exec((err, coupondetails) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Search coupon details fetched",
            data: coupondetails
          });
        }
      });
  },

  blockcoupon: (coupondata, callback) => {
    Coupons.update({
      _id: coupondata._id
    }, {
        block: true
      })
      .exec((err, data) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Coupon blocked"
          });
        }
      });
  },

  unblockcoupon: (coupondata, callback) => {
    Coupons.update({
      _id: coupondata._id
    }, {
        block: false
      })
      .exec((err, data) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Coupon unblocked"
          });
        }
      });
  },

  getonecoupondata: (couponid, callback) => {
    Coupons.findOne({
      _id: couponid
    })
      .exec((err, coupondetails) => {
        if (err) {
          callback({
            status: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          if (coupondetails == null) {
            callback({
              status: false,
              message: "Some internal error has occurred"
            });
          } else {
            callback({
              success: true,
              message: "Coupon data fetched",
              data: coupondetails
            });
          }
        }
      });
  },

  updatecoupon: (coupondata, callback) => {
    async.waterfall([
      (nextcb) => {
        if (coupondata.category_id == undefined || coupondata.category_id == '') {
          callback({
            success: false,
            message: "Please select a category"
          });
        } else if (coupondata.coupon_name == undefined || coupondata.coupon_name == '') {
          callback({
            success: false,
            message: "Please enter coupon name"
          });
        } else if (coupondata.coupon_description == undefined || coupondata.coupon_description == '') {
          callback({
            success: false,
            message: "Please enter coupon description"
          });
        } else if (coupondata.barcode_id == undefined || coupondata.barcode_id == '') {
          callback({
            success: false,
            message: "Please enter barcode Id"
          });
        } else if (coupondata.original_price == undefined || coupondata.original_price == '') {
          callback({
            success: false,
            message: "Please enter original price"
          });
        } else if (coupondata.discount_percent == undefined || coupondata.discount_percent == '') {
          callback({
            success: false,
            message: "Please enter discount percentage"
          });
        } else if (coupondata.discount_price == undefined || coupondata.discount_price == '') {
          callback({
            success: false,
            message: "Please enter discount price"
          });
        }
        else if (coupondata.cashback_percent == undefined || coupondata.cashback_percent == '') {
          callback({
            success: false,
            message: "Please enter cashback percent"
          });
        }
        else if (coupondata.address == undefined || coupondata.address == '') {
          callback({
            success: false,
            message: "Please enter coupon address"
          });
        } else if (coupondata.address_lat == undefined || coupondata.address_lat == '') {
          callback({
            success: false,
            message: "Invalid Address"
          });
        } else if (coupondata.address_long == undefined || coupondata.address_long == '') {
          callback({
            success: false,
            message: "Invalid Address"
          });
        } else if (coupondata.expire_date == undefined || coupondata.address_long == '') {
          callback({
            success: false,
            message: "Please select an expire date"
          });
        } else {
          nextcb(null);
        }
      },
      (nextcb) => {
        Coupons.count({
          coupon_name: coupondata.coupon_name
        }, (err, couponcount) => {
          if (err) {
            nextcb(err);
          } else {
            if (couponcount > 0) {
              callback({
                status: false,
                message: "Coupon name already exists"
              });
            } else {
              nextcb(null);
            }
          }
        });
      },
      (nextcb) => {
        Coupons.update({
          _id: coupondata._id
        }, {
            //coupon_id: coupondata.coupon_id,
            category_id:coupondata.category_id,
            coupon_name: coupondata.coupon_name,
            coupon_description: coupondata.coupon_description,
            original_price: coupondata.original_price,
            discount_percent: coupondata.discount_percent,
            discount_price: coupondata.discount_price,
            cashback_percent: coupondata.cashback_percent,
            address: coupondata.address,
            barcode_id:coupondata.barcode_id,
            address_lat: coupondata.address_lat,
            address_long: coupondata.address_long,
            expire_date: coupondata.expire_date,
          }).exec((err, data) => {
            if (err) {
              nextcb(err);
            } else {
              nextcb(null);
            }
          });
      }
    ],
      (err) => {
        if (err) {
          callback({
            success: false,
            message: "Some internal error has occurred",
            err: err
          });
        } else {
          callback({
            success: true,
            message: "Coupon updated successfully"
          });
        }
      });
  },

  removecoupon: (coupondata, callback) => {
    if (coupondata.coupon_id == undefined || coupondata.coupon_id == '') {
      callback({
        success: false,
        message: "Invalid coupon Id"
      });
    } else {
      Coupons.remove({
        _id: coupondata.coupon_id
      })
        .exec((err) => {
          if (err) {
            callback({
              success: false,
              message: "Some internal error has occurred",
              err: err
            });
          } else {
            callback({
              success: true,
              message: "Coupon removed successfully"
            });
          }
        });
    }
  },

};
module.exports = adminService;
