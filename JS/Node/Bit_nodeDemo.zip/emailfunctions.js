var nodemailer = require('nodemailer');
var EmailConnections = 'smtps://avijit.team@gmail.com:avijit_team@smtp.gmail.com';
//var __logoPath = 'http://162.243.110.92:4334/public/logo.png';
var __logoPath = 'http://nodeserver.brainiuminfotech.com:1905/assets/imgs/logo.png';
var EmailService = {
	
	EVehicleRegistration: function (vehicleData){
	var transporter = nodemailer.createTransport(EmailConnections);
	
    var mailOptions = {
        from: '"SLAD Admin" <avijit.team@gmail.com>', // sender address
        to: vehicleData.email, // list of receivers
        subject: 'Registration Done', // Subject line
        //text: 'Hello world', // plaintext body
        html: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head><body bgcolor="#ededed"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ededed" ><tr><td><table width="60%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFF" align="center" style="border-radius:10px; border:1px solid #ededed; box-shadow: 0 0 15px 0 rgba(0, 0, 0, 0.25); margin: auto;"><tr><td valign="top" align="center" style="padding: 15px"><img src="'+__logoPath+'" alt="SLAD" title="SLAD" style="border:0;width:200px;"/></td></tr><tr><td valign="top" style="padding: 40px;" height="200">Hello,<br><br>Welcome to SLAD,<br><br>You have been successfully registered for SLAD Transit App. To login please use the following credentials:<br><br> <b>Email:</b> '+vehicleData.email+' <br> <b>Password:</b> '+vehicleData.password+'. <br><br>Please login to the App to check for more details.<br><br> Thank you<br>SLAD Admin</td></tr><tr><td style="padding: 15px" align="center" bgcolor="#FFF"><p style="font:normal 12px Arial, Helvetica, sans-serif;"></p></td></tr></table></td></tr></table></body></html>' // html body
    };
	// send mail with defined transport object
	transporter.sendMail(mailOptions, function(error, info){
		if(error){
			console.log('Message not sent: ' + error);	                                
		} else {
			console.log('Message sent: ' + info.response);
		}
	});
},

	transitForgotPassword: function (forgotpasswordData,userdetails){
	var transporter = nodemailer.createTransport(EmailConnections);
	
    var mailOptions = {
        from: '"SLAD Admin" <avijit.team@gmail.com>', // sender address
        to: forgotpasswordData.email, // list of receivers
        subject: 'New Password', // Subject line
        //text: 'Hello world', // plaintext body
        html: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head><body bgcolor="#ededed"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ededed" ><tr><td><table width="60%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFF" align="center" style="border-radius:10px; border:1px solid #ededed; box-shadow: 0 0 15px 0 rgba(0, 0, 0, 0.25); margin: auto;"><tr><td valign="top" align="center" style="padding: 15px"><img src="'+__logoPath+'" alt="SLAD" title="SLAD" style="border:0;width:200px;"/></td></tr><tr><td valign="top" style="padding: 40px;" height="200">Hello,<br><br>We have received your application for new password. <br><br> Your new password is <strong>' + forgotpasswordData.newpassword + '</strong> <br><br> Please change this password ASAP for security purpose. <br><br> Thank you<br>SLAD Admin</td></tr><tr><td style="padding: 15px" align="center" bgcolor="#FFF"><p style="font:normal 12px Arial, Helvetica, sans-serif;"></p></td></tr></table></td></tr></table></body></html>' // html body
    };
	// send mail with defined transport object
	transporter.sendMail(mailOptions, function(error, info){
		if(error){
			console.log('Message not sent: ' + error);	                                
		} else {
			console.log('Message sent: ' + info.response);
		}
	});
},

	ApplyJobNotification: function (ownerData,applicationData){
	var transporter = nodemailer.createTransport(EmailConnections);
	
	    var mailOptions = {
	        from: '"SLAD" <avijit.team@gmail.com>', // sender address
	        to: ownerData.email, // list of receivers
	        subject: 'A new application received for - "'+ownerData.job_title+'"', // Subject line
	        //text: 'Hello world', // plaintext body
	        html: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head><body bgcolor="#ededed"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ededed" ><tr><td><table width="60%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFF" align="center" style="border-radius:10px; border:1px solid #ededed; box-shadow: 0 0 15px 0 rgba(0, 0, 0, 0.25); margin: auto;"><tr><td valign="top" align="center" style="padding: 15px"><img src="'+__logoPath+'" alt="SLAD" title="SLAD" style="border:0;width:200px;"/></td></tr><tr><td valign="top" style="padding: 40px;" height="200">Hello '+ownerData.first_name+',<br><br>A user has expressed his interest for your job - "'+ownerData.job_title+'". You can contact with the user with below details:<br/>Email: '+applicationData.user_email+'<br/>Contact No: '+applicationData.user_contact+'<br><br> Thank you<br>SLAD Admin</td></tr><tr><td style="padding: 15px" align="center" bgcolor="#FFF"><p style="font:normal 12px Arial, Helvetica, sans-serif;">Copyright @2018 SLAD, All rights reserved.</p></td></tr></table></td></tr></table></body></html>' // html body
	    };
		// send mail with defined transport object
		transporter.sendMail(mailOptions, function(error, info){
			if(error){
				console.log('Message not sent: ' + error);	                                
			} else {
				console.log('Message sent: ' + info.response);
			}
		});
	},

	ApproveJobNotification: function (jobmateData,bossmateData,jobdetails){ console.log("jobmateData",jobmateData);
	var transporter = nodemailer.createTransport(EmailConnections);
	
	    var mailOptions = {
	        from: '"SLAD" <avijit.team@gmail.com>', // sender address
	        to: jobmateData.email, // list of receivers
	        //to: "sourodipta.amstech@gmail.com",
	        subject: 'Application approval - "'+jobdetails.title+'"', // Subject line
	        //text: 'Hello world', // plaintext body
	        html: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head><body bgcolor="#ededed"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ededed" ><tr><td><table width="60%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFF" align="center" style="border-radius:10px; border:1px solid #ededed; box-shadow: 0 0 15px 0 rgba(0, 0, 0, 0.25); margin: auto;"><tr><td valign="top" align="center" style="padding: 15px"><img src="'+__logoPath+'" alt="SLAD" title="SLAD" style="border:0;width:200px;"/></td></tr><tr><td valign="top" style="padding: 40px;" height="200">Hello '+jobmateData.first_name+',<br><br>Congratulations!! Your application for - '+jobdetails.title+' has been accepted by '+bossmateData.first_name+" "+bossmateData.last_name+'. For further queries, you may contact him/her with below details:<br/>Name: '+bossmateData.first_name+" "+bossmateData.last_name+'<br/>Email: '+bossmateData.email+'<br/>Contact No: '+bossmateData.contact_no+'<br><br> Thank you<br>SLAD Admin</td></tr><tr><td style="padding: 15px" align="center" bgcolor="#FFF"><p style="font:normal 12px Arial, Helvetica, sans-serif;">Copyright @2018 SLAD, All rights reserved.</p></td></tr></table></td></tr></table></body></html>' // html body
	    };	
		// send mail with defined transport object
		transporter.sendMail(mailOptions, function(error, info){			
			if(error){
				console.log('Message not sent: ' + error);	                                
			} else {
				console.log('Message sent: ' + info.response);
			}
		});
	},

	DeclineJobNotification: function (jobmateData,bossmateData,jobdetails){ 
	var transporter = nodemailer.createTransport(EmailConnections);
	
	    var mailOptions = {
	        from: '"SLAD" <avijit.team@gmail.com>', // sender address
	        to: jobmateData.email, // list of receivers
	        // to: "uzra.brainium@gmail.com",
	        //to: "sourodipta.amstech@gmail.com",
	        subject: 'Application Declined - "'+jobdetails.title+'"', // Subject line	      
	        html: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head><body bgcolor="#ededed"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ededed" ><tr><td><table width="60%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFF" align="center" style="border-radius:10px; border:1px solid #ededed; box-shadow: 0 0 15px 0 rgba(0, 0, 0, 0.25); margin: auto;"><tr><td valign="top" align="center" style="padding: 15px"><img src="'+__logoPath+'" alt="SLAD" title="SLAD" style="border:0;width:200px;"/></td></tr><tr><td valign="top" style="padding: 40px;" height="200">Hello '+jobmateData.first_name+',<br><br>Sorry!! Unfortunately in this instance your application for - '+jobdetails.title+' has not been selected by '+bossmateData.first_name+" "+bossmateData.last_name+'. So you may continue applying for jobs. Good luck. <br><br> Thank you<br>SLAD Admin</td></tr><tr><td style="padding: 15px" align="center" bgcolor="#FFF"><p style="font:normal 12px Arial, Helvetica, sans-serif;">Copyright @2018 SLAD, All rights reserved.</p></td></tr></table></td></tr></table></body></html>' // html body
	    };		
		// send mail with defined transport object
		transporter.sendMail(mailOptions, function(error, info){			
			if(error){
				console.log('Message not sent: ' + error);	                                
			} else {
				console.log('Message sent: ' + info.response);
			}
		});
	},


   FinalApproveJobNotification: function (jobmateData,bossmateData,jobdetails){ 
   	//console.log("jobmateData",jobmateData);
	
	var transporter = nodemailer.createTransport(EmailConnections);
	
	    var mailOptions = {
	        from: '"SLAD" <avijit.team@gmail.com>', // sender address
	        to: jobmateData.email, // list of receivers
	      //  to: "sourodipta.amstech@gmail.com",
	        subject: 'Application selected - "'+jobdetails.title+'"', // Subject line	       
	        html: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head><body bgcolor="#ededed"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ededed" ><tr><td><table width="60%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFF" align="center" style="border-radius:10px; border:1px solid #ededed; box-shadow: 0 0 15px 0 rgba(0, 0, 0, 0.25); margin: auto;"><tr><td valign="top" align="center" style="padding: 15px"><img src="'+__logoPath+'" alt="SLAD" title="SLAD" style="border:0;width:200px;"/></td></tr><tr><td valign="top" style="padding: 40px;" height="200">Hello '+jobmateData.first_name+',<br><br>Congratulations!! Your application for - '+jobdetails.title+' has been selected by '+bossmateData.first_name+" "+bossmateData.last_name+'. For further queries, you may contact him/her with below details:<br/>Name: '+bossmateData.first_name+" "+bossmateData.last_name+'<br/>Email: '+bossmateData.email+'<br/>Contact No: '+bossmateData.contact_no+'<br><br> Thank you<br>SLAD Admin</td></tr><tr><td style="padding: 15px" align="center" bgcolor="#FFF"><p style="font:normal 12px Arial, Helvetica, sans-serif;">Copyright @2018 SLAD, All rights reserved.</p></td></tr></table></td></tr></table></body></html>' // html body
	    };
		// send mail with defined transport object
		transporter.sendMail(mailOptions, function(error, info){
			if(error){
				console.log('Message not sent: ' + error);	                                
			} else {
				console.log('Message sent: ' + info.response);
			}
		});
	},

	 LocTrackNotification: function (jobmateData,bossmateData,jobdetails){ 
   	//console.log("jobmateData",jobmateData);	
	var transporter = nodemailer.createTransport(EmailConnections);
    // setup e-mail data with unicode symbols
	    var mailOptions = {
	        from: '"SLAD" <avijit.team@gmail.com>', // sender address
	        to: bossmateData.email, // list of receivers
	        //to: "sourodipta.amstech@gmail.com",
	        subject: 'Track Job - "'+jobdetails.title+'"', // Subject line
	        //text: 'Hello world', // plaintext body
	        html: '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head><body bgcolor="#ededed"><table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ededed" ><tr><td><table width="60%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFF" align="center" style="border-radius:10px; border:1px solid #ededed; box-shadow: 0 0 15px 0 rgba(0, 0, 0, 0.25); margin: auto;"><tr><td valign="top" align="center" style="padding: 15px"><img src="'+__logoPath+'" alt="SLAD" title="SLAD" style="border:0;width:200px;"/></td></tr><tr><td valign="top" style="padding: 40px;" height="200">Hello '+bossmateData.first_name+',<br><br>The applicant, '+jobmateData.first_name+' is heading towards -'+jobdetails.title+' location. You may track the location from the job applicant list.<br><br> Thank you<br>SLAD Admin</td></tr><tr><td style="padding: 15px" align="center" bgcolor="#FFF"><p style="font:normal 12px Arial, Helvetica, sans-serif;">Copyright @2018 SLAD, All rights reserved.</p></td></tr></table></td></tr></table></body></html>'
	    };
		// send mail with defined transport object
		transporter.sendMail(mailOptions, function(error, info){
			if(error){
				console.log('Message not sent: ' + error);	                                
			} else {
				console.log('Message sent: ' + info.response);
			}
		});
	},


};
module.exports = EmailService;