module.exports = {
  //"database" : "mongodb://localhost:27017/frasgo",
  "database" : "mongodb://localhost:27017/SLADApp?authSource=admin",
  //"username" : 'mongoAdminBIT',//older server
  "username" : 'brain1uMMong0User',
  //"password" :'BiT^7129~jsQ​-P',//older server
  //"password" :'PL6bnU5puvX6pBz',
    "password" :'PL5qnU9nuvX0pBa',
	"port" : process.env.PORT || 1905,
	"secretKey" : "hyrgqwjdfbw4534efqrwer2q38945765",
	dev_mode : true,
    __root_dir: __dirname,   
	__site_url: 'http://nodeserver.brainiuminfotech.com:1905/',
    //__baseurl: 'http://localhost:4200/#/'
    //__baseurl: 'http://162.243.110.92/aviknath/frasgo/frasgoadmin/#/'//older server
  //  __baseurl: 'http://nodeserver.brainiuminfotech.com/pinki/carenow/'
    _baseUrl: 'http://nodeserver.brainiuminfotech.com:1905/'
}
