var mongoose = require("mongoose");
var bcrypt = require('bcrypt-nodejs');
var Schema = mongoose.Schema;

var VehicleSchema = new mongoose.Schema({
    name: { type: String, default: '' },    
    email: { type: String, required: true, index: { unique: true } },
    password: { type: String, required: true },
    mobile: { type: String, default: '' },
    vehicle_no: { type: String, required: true },
    authtoken: { type: String, default: '' },
    devicetoken: { type: String, default: '' },
    social_id: {type: String, default: ''},

    // email_verified: { type: Boolean, default: false },    
    // block: { type: Boolean, default: false },
    // login_type: { type: String, enum:['normal','fb'] ,default: 'normal' },   
}, {
        timestamps: true
    });

VehicleSchema.pre('save', function (next) {
    var user = this;
    if (!user.isModified('password')) return next();

    bcrypt.hash(user.password, null, null, function (err, hash) {
        if (err) {
            return next(err);
        }
        user.password = hash;
        next();
    });
    user.email = user.email.toLowerCase();
});

VehicleSchema.methods.comparePassword = function (password) {
    var user = this;
    return bcrypt.compareSync(password, user.password);
};

module.exports = mongoose.model("EVehicle", VehicleSchema);
