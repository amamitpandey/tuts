var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var ReviewSchema = new mongoose.Schema({
    coupon_id: { type: Schema.Types.ObjectId, required: true, ref: "Coupon" },
    user_id: { type: Schema.Types.ObjectId, required: true, ref: "User" },
    review_title: { type: String, required: true },
    review_description: { type: String, required: true },
    rating: { type: Number, default: 0 },
}, {
        timestamps: true
    });

module.exports = mongoose.model("Review", ReviewSchema);