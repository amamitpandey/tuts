var express = require('express'),
app = express()

app.use('/assets', express.static('assets'));

// for encode json/formData
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

//===========================CORS support==============================
app.use((req, res, next) => {
    req.setEncoding('utf8');
    // Website you wish to allow to connect
    res.setHeader("Access-Control-Allow-Origin", "*");
    
    // Request methods you wish to allow
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, PATCH, DELETE");
    
    // Request headers you wish to allow
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    if ('OPTIONS' == req.method) {
        res.sendStatus(200);
    } else {
        next();
    }
});

// for connecting database
mongoose = require('mongoose')

// for Live server
mongoose.connect('mongodb://brain1uMMong0User:PL5qnU9nuvX0pBa@localhost:27017/amitpandey?authSource=admin',{useUnifiedTopology: true,
useNewUrlParser: true,useCreateIndex: true}); 

// for Localhost server
// mongoose.connect('mongodb://localhost:27017/amit',{useUnifiedTopology: true,
// useNewUrlParser: true,useCreateIndex: true});

app.get('/', (req, res) => res.sendfile('views/index.html'))



const routes = require('./routes/routes')
app.use('/api', routes)

port = process.env.PORT || 3987,
app.listen(port);


console.log('todo list RESTful API server started on: ' + port);