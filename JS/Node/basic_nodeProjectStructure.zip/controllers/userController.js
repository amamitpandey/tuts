var bcrypt = require('bcrypt');
var dbService=require('../service/service');
var valditation=require('../service/loginValidation');



// get all userList
exports.userList = (req, res) =>  {
    
    dbService.userListService(req,res).then(data=>{
        //console.log("test_return",data)
        res.json({status:true,type:true,message:"Data fetched",data})
    })
    .catch(e=>{
        //console.log("test_return_e",e)
        res.status(400).json({status:true,type:false,message:"Data not fetched",e})
    });
};


// for get userList by id
exports.userDetailsId = (req,res)=>{
    if(req.params.id != undefined && req.params.id != null && req.params.id != ''){
        dbService.userDetailsservice(req).then(data=>{
            res.json({status:true,type:true,message:"Data fetched",data})
        })
        .catch(e=>{
            res.status(400).json({status:true,type:false,message:"Data not fetched",e})
        })
    }else{
        res.status(400).json({status:true,type:false,message:"Kindly enter userId"})
    }
};

// for create user
exports.createUser = (req,res)=>{
    let data=req.body
    if(data.title == undefined || data.title == null || data.title == ''){
        res.status(400).json({status:true,type:false,message:"Please mention title"})
    }else if(data.firstname == undefined || data.firstname == null || data.firstname == ''){
        res.status(400).json({status:true,type:false,message:"Please mention firstname"})
    }else if(data.lastname == undefined || data.lastname == null || data.lastname == ''){
        res.status(400).json({status:true,type:false,message:"Please mention lastname"})
    }else if(data.email == undefined || data.email == null || data.email == ''){
        res.status(400).json({status:true,type:false,message:"Please mention email"})
        
    }else if(data.password == undefined || data.password == null || data.password == ''){
        res.status(400).json({status:true,type:false,message:"Please mention password"})
    }else if(!valditation.validateEmail(data.email)){
        res.status(400).json({status:true,type:false,message:"Please valid email"})
    }
    //checking email if exit
    dbService.checkEmail(data.email).then(data=>{
        //console.log("email_data",data);
        if(data==true){
            res.status(200).json({status:false,message:"Email already exit please try another one"})
        }
    }).catch(e=>{
        console.log("err_email_exit",e);
    });
    
    // save data in db
    dbService.userRegisterservice(req,res).then(data=>{
        //console.log("test_return",data)
        res.json({status:true,message:"Register successfully",data})
    })
    .catch(e=>{
        console.log("test_return_e",e)
        res.status(400).json({status:true,message:"Data not fetched",e})
    })
};

// for login
exports.doLogin = (req,res)=>{
    console.log("test_return",req.body)
    let data=req.body
    
    if(data.email == undefined || data.email == null || data.email == ''){
        res.status(200).json({status:true,type:false,message:"Please mention email"})  
    }else if(data.password == undefined || data.password == null || data.password == ''){
        res.status(200).json({status:true,type:false,message:"Please mention password"})
    }else if(!valditation.validateEmail(data.email)){
        res.status(200).json({status:true,type:false,message:"Please valid email"})
    }
    
    dbService.doLogin(data).then(data=>{
        console.log("test_return_data",data)
        if(data.status==true){
            res.status(200).json({status:true,message:"Welcome to ocir",data:data.data})
        }
        if(data.status==false){
            res.status(200).json({status:false,message:"Kindly Register Frist!!!",data:data.data})
        }
    }).catch(e=>{
        res.status(400).json({status:false,message:"Data not fetched",e})
    })
};


