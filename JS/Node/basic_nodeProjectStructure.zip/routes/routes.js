var express = require('express')
const userController = require('../controllers/userController')
const router = express.Router()
 
router.get('/userList', userController.userList)
router.post("/userList/:id?", userController.userDetailsId)
router.post("/createUser", userController.createUser)
router.post("/doLogin", userController.doLogin)
 
module.exports = router