// for model to structure data
var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var bcrypt = require('bcrypt');


var userSchema=new Schema({ //if table not exit auto create table
    title:  {type:String,required: true},
    firstname:  {type:String,required: true},
    lastname:  {type:String,required: true},
    email:  {type: String,required: true,unique: true},
    password:  {type:String,required: [true, 'am Password is empty']}
},{
    timestamps: { createdAt: 'created_at',updatedAt:'updated_at' }
});

userSchema.pre('save', function (next) {
    var user = this;
    if (!user.isModified('password')) return next()
    bcrypt.hash(user.password, 10, function(err, hash) {
        // Store hash in your password DB.
        if (err) {
            return next(err);
        }
        user.password = hash;
        next();
        user.email = user.email.toLowerCase();
    })
});



userSchema.methods.comparePassword = function (password) {
    var user = this;
    return bcrypt.compareSync(password, user.password);
};

module.exports = mongoose.model('userDetail',userSchema);