const userModel=require('../models/userModel')

exports.userListService=()=>{
    return new Promise((resolve,reject)=>{
        userModel.find({}).select('title firstname lastname email').exec((err, task)=>{
            if (err)
            reject(err)
            resolve(task)
        });
    }) 
}

exports.userDetailsservice=(req)=>{
    return new Promise((resolve,reject)=>{
        userModel.findById(req.params.id).then((user)=>{
            if(user)
            resolve(user)
            else
            reject(err)
        }).catch((err)=>{
            reject(err)
        })
    });
}

exports.checkEmail=(req)=>{
    return new Promise((resolve,reject)=>{
        userModel.findOne({ email: req }, function(err, user) {
            //console.log("data",user,"err",err);
            if (user != null && err==null){
                //console.log("data",user);
                resolve(true)
            } 
            if(err==null && user == null){
                //console.log("err1",err);
                resolve(false)
            }
        })
        .catch(e=>{reject(e)})
        
    })
}

exports.doLogin=(req)=>{
    return new Promise((resolve,reject)=>{
        userModel.findOne({ email: req.email }, function(err, user) {
            console.log("data",user,"err",err);
            if (user != null && err==null){
                // test a matching password
                if(user.comparePassword(req.password)){
                    resolve({status:true,data:user})
                }
                else{
                    resolve({status:false,data:""})
                }
            } 
            if(err==null && user == null){
                //console.log("err1",err);
                resolve({status:false,data:""})
            }
        })
        .catch(e=>{
            //console.log("err1",err);
            reject(e)
        })
    })
}



exports.userRegisterservice=(req)=>{
    return new Promise((resolve,reject)=>{
        userModel.create(req.body).then((user)=>{
            resolve(user)
        }).catch((err)=>{
            reject(err)
        })
    })
}


