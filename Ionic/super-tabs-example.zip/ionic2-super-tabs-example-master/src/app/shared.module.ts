import { NgModule } from '@angular/core';
import { SuperTabsModule } from 'ionic2-super-tabs';
// import { SuperTabsModule } from 'ionic2-super-tabs';

@NgModule({
  exports: [
    SuperTabsModule
  ]
})
export class SharedModule {}
