import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { IonicTabsPage_1Page } from './ionic-tabs-page-1';

@NgModule({
  declarations: [
    IonicTabsPage_1Page,
  ],
  imports: [
    IonicPageModule.forChild(IonicTabsPage_1Page),
  ],
})
export class IonicTabsPage_1PageModule {}
