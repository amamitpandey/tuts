import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { IonicTabsPage_2Page } from './ionic-tabs-page-2';

@NgModule({
  declarations: [
    IonicTabsPage_2Page,
  ],
  imports: [
    IonicPageModule.forChild(IonicTabsPage_2Page),
  ],
})
export class IonicTabsPage_2PageModule {}
