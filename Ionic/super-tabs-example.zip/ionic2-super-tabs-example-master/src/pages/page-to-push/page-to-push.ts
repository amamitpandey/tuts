import { Component } from '@angular/core';
import { NavController, NavParams, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-page-to-push',
  templateUrl: 'page-to-push.html'
})
export class PageToPushPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) { }

}
