This is a demo project demonstrating the usage of [ionic2-super-tabs module](https://github.com/zyra/ionic2-super-tabs). If you are experiencing any issues with the module, please post the issues at the module's repo.

To use this project:
```shell
git clone https://github.com/zyra/ionic2-super-tabs-example
cd ionic2-super-tabs-example
git submodule init
git submodule update
npm i
ionic serve
```


![Example](https://github.com/zyra/ionic2-super-tabs-example/blob/master/example.gif?raw=true)
